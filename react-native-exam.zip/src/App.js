import SignupScreen from "./components/SignupScreen";

const App = () => {
    return(
        <SignupScreen />
    )
}

export default App;
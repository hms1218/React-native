import StackNavigation from "./navigation/StackNavigation";

const App = () => {
    return(
        <StackNavigation />
    )
}

export default App;